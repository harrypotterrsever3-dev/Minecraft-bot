export default function StatsPanel({ bot }) {
  if (!bot) return (
    <div style={{ padding: '40px', textAlign: 'center', color: '#6e7681', fontSize: '14px' }}>
      Select a bot to view stats
    </div>
  );

  const stats = [
    { icon: '🏓', label: 'Ping', value: bot.ping ? `${bot.ping}ms` : '--', color: getPingColor(bot.ping) },
    { icon: '❤️', label: 'Health', value: bot.health !== undefined ? `${Math.round(bot.health)}/20` : '--', color: '#f87171' },
    { icon: '🍗', label: 'Food', value: bot.food !== undefined ? `${Math.round(bot.food)}/20` : '--', color: '#fb923c' },
    { icon: '👥', label: 'Players', value: bot.playerCount ?? '--', color: '#60a5fa' },
    { icon: '🔄', label: 'Reconnects', value: bot.stats?.reconnects ?? 0, color: '#a78bfa' },
    { icon: '📤', label: 'Msgs Sent', value: bot.stats?.messagesSent ?? 0, color: '#34d399' },
  ];

  return (
    <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
        {stats.map(s => (
          <div key={s.label} style={{
            background: '#161b22', border: '1px solid #21262d', borderRadius: '10px', padding: '12px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '22px', marginBottom: '6px' }}>{s.icon}</div>
            <div style={{ color: s.color, fontSize: '16px', fontWeight: 700, fontFamily: 'JetBrains Mono' }}>{s.value}</div>
            <div style={{ color: '#6e7681', fontSize: '10px', marginTop: '2px', letterSpacing: '0.06em' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Health bar */}
      {bot.health !== undefined && (
        <div style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '10px', padding: '14px' }}>
          <div style={{ color: '#8b949e', fontSize: '12px', marginBottom: '10px', fontWeight: 600 }}>❤️ Health & Food</div>
          <div style={{ marginBottom: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
              <span style={{ color: '#f87171', fontSize: '11px' }}>Health</span>
              <span style={{ color: '#f87171', fontSize: '11px', fontFamily: 'JetBrains Mono' }}>{Math.round(bot.health || 0)}/20</span>
            </div>
            <div style={{ height: '6px', background: '#21262d', borderRadius: '3px' }}>
              <div style={{ width: `${((bot.health || 0) / 20) * 100}%`, height: '100%', background: 'linear-gradient(90deg, #f87171, #ef4444)', borderRadius: '3px', transition: 'width 0.5s ease' }} />
            </div>
          </div>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
              <span style={{ color: '#fb923c', fontSize: '11px' }}>Food</span>
              <span style={{ color: '#fb923c', fontSize: '11px', fontFamily: 'JetBrains Mono' }}>{Math.round(bot.food || 0)}/20</span>
            </div>
            <div style={{ height: '6px', background: '#21262d', borderRadius: '3px' }}>
              <div style={{ width: `${((bot.food || 0) / 20) * 100}%`, height: '100%', background: 'linear-gradient(90deg, #fb923c, #f97316)', borderRadius: '3px', transition: 'width 0.5s ease' }} />
            </div>
          </div>
        </div>
      )}

      {/* Position */}
      {bot.position && (
        <div style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '10px', padding: '14px' }}>
          <div style={{ color: '#8b949e', fontSize: '12px', marginBottom: '8px', fontWeight: 600 }}>📍 Position</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: '12px', color: '#4ade80' }}>
            X: {Math.round(bot.position.x)} &nbsp; Y: {Math.round(bot.position.y)} &nbsp; Z: {Math.round(bot.position.z)}
          </div>
        </div>
      )}

      {/* Player list */}
      {bot.players?.length > 0 && (
        <div style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '10px', padding: '14px' }}>
          <div style={{ color: '#8b949e', fontSize: '12px', marginBottom: '10px', fontWeight: 600 }}>
            👥 Online Players ({bot.playerCount})
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '200px', overflowY: 'auto' }}>
            {bot.players.map((p, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#4ade80' }} />
                  <span style={{ color: '#c9d1d9', fontSize: '13px' }}>{p.username}</span>
                </div>
                <span style={{ color: getPingColor(p.ping), fontSize: '11px', fontFamily: 'JetBrains Mono' }}>
                  {p.ping}ms
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function getPingColor(ping) {
  if (!ping) return '#6e7681';
  if (ping < 50) return '#4ade80';
  if (ping < 100) return '#fbbf24';
  if (ping < 200) return '#fb923c';
  return '#f87171';
}
