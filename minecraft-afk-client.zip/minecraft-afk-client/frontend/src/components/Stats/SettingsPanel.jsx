import { useState } from 'react';
import { useSocket } from '../../hooks/useSocket';
import toast from 'react-hot-toast';

export default function SettingsPanel() {
  const { settings, updateSettings } = useSocket();
  const [form, setForm] = useState(settings);
  const [saved, setSaved] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = () => {
    updateSettings(form);
    setSaved(true);
    toast.success('Settings saved!');
    setTimeout(() => setSaved(false), 2000);
  };

  const inputStyle = {
    background: '#0d1117', border: '1px solid #30363d', borderRadius: '8px',
    padding: '9px 14px', color: '#c9d1d9', fontSize: '13px', outline: 'none',
    fontFamily: 'JetBrains Mono', width: '100%', boxSizing: 'border-box',
    transition: 'border-color 0.2s'
  };
  const labelStyle = { color: '#8b949e', fontSize: '12px', fontWeight: 600, display: 'block', marginBottom: '6px' };

  return (
    <div style={{ padding: '20px', maxWidth: '600px' }}>
      <h3 style={{ color: '#c9d1d9', marginTop: 0, marginBottom: '20px', fontSize: '18px' }}>⚙️ Global Settings</h3>

      <section style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '12px', padding: '18px', marginBottom: '16px' }}>
        <div style={{ color: '#4ade80', fontSize: '13px', fontWeight: 600, marginBottom: '14px' }}>🔄 Reconnect</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
          <div>
            <label style={labelStyle}>Reconnect Delay (ms)</label>
            <input type="number" value={form.reconnectDelay || 5000} onChange={e => set('reconnectDelay', +e.target.value)}
              style={inputStyle} onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
          </div>
          <div>
            <label style={labelStyle}>Max Attempts (-1 = unlimited)</label>
            <input type="number" value={form.maxReconnectAttempts ?? -1} onChange={e => set('maxReconnectAttempts', +e.target.value)}
              style={inputStyle} onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
          </div>
        </div>
      </section>

      <section style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '12px', padding: '18px', marginBottom: '16px' }}>
        <div style={{ color: '#4ade80', fontSize: '13px', fontWeight: 600, marginBottom: '14px' }}>🎮 AFK Movement</div>
        <label style={labelStyle}>Movement Interval (ms)</label>
        <input type="number" value={form.afkMovementInterval || 30000} onChange={e => set('afkMovementInterval', +e.target.value)}
          style={inputStyle} onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
        <div style={{ color: '#6e7681', fontSize: '11px', marginTop: '6px' }}>Bot performs random micro-moves to avoid AFK kick</div>
      </section>

      <section style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '12px', padding: '18px', marginBottom: '16px' }}>
        <div style={{ color: '#4ade80', fontSize: '13px', fontWeight: 600, marginBottom: '14px' }}>💬 Chat Filter</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
          <Toggle value={form.chatFilterEnabled} onChange={v => set('chatFilterEnabled', v)} />
          <span style={{ color: '#8b949e', fontSize: '13px' }}>Enable chat filter</span>
        </div>
        {form.chatFilterEnabled && (
          <div>
            <label style={labelStyle}>Filter words (comma separated)</label>
            <input value={(form.chatFilterWords || []).join(', ')}
              onChange={e => set('chatFilterWords', e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
              placeholder="spam, advert, discord.gg"
              style={inputStyle} onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
          </div>
        )}
      </section>

      <section style={{ background: '#161b22', border: '1px solid #21262d', borderRadius: '12px', padding: '18px', marginBottom: '16px' }}>
        <div style={{ color: '#4ade80', fontSize: '13px', fontWeight: 600, marginBottom: '14px' }}>🔐 Auto Commands (Global Default)</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>
          <Toggle value={form.autoRegister} onChange={v => set('autoRegister', v)} />
          <span style={{ color: '#8b949e', fontSize: '13px' }}>Auto /register on join</span>
        </div>
        {form.autoRegister && (
          <input type="password" value={form.registerPassword || ''} onChange={e => set('registerPassword', e.target.value)}
            placeholder="Register password" style={{ ...inputStyle, marginBottom: '12px' }}
            onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>
          <Toggle value={form.autoLogin} onChange={v => set('autoLogin', v)} />
          <span style={{ color: '#8b949e', fontSize: '13px' }}>Auto /login on join</span>
        </div>
        {form.autoLogin && (
          <input type="password" value={form.loginPassword || ''} onChange={e => set('loginPassword', e.target.value)}
            placeholder="Login password" style={inputStyle}
            onFocus={e => e.target.style.borderColor='#4ade80'} onBlur={e => e.target.style.borderColor='#30363d'} />
        )}
      </section>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
        <Toggle value={form.soundNotifications} onChange={v => set('soundNotifications', v)} />
        <span style={{ color: '#8b949e', fontSize: '13px' }}>🔔 Sound notifications (browser)</span>
      </div>

      <button onClick={handleSave} style={{
        padding: '12px 28px', background: saved ? '#22c55e' : 'linear-gradient(135deg, #4ade80, #22c55e)',
        border: 'none', borderRadius: '10px', color: '#0a0e1a',
        fontSize: '14px', fontWeight: 700, cursor: 'pointer', fontFamily: 'Space Grotesk',
        transition: 'all 0.2s'
      }}>
        {saved ? '✅ Saved!' : '💾 Save Settings'}
      </button>
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <div onClick={() => onChange(!value)} style={{
      width: '40px', height: '22px', borderRadius: '11px', cursor: 'pointer',
      background: value ? '#4ade80' : '#21262d', transition: 'background 0.2s',
      position: 'relative', flexShrink: 0
    }}>
      <div style={{
        width: '18px', height: '18px', borderRadius: '50%', background: '#fff',
        position: 'absolute', top: '2px', transition: 'left 0.2s',
        left: value ? '20px' : '2px'
      }} />
    </div>
  );
}
