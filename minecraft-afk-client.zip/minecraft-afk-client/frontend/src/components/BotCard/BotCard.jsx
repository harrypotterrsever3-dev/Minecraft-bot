import { useState, useEffect, useRef } from 'react';
import { useSocket } from '../../hooks/useSocket';

const STATUS_CONFIG = {
  connected:    { color: '#4ade80', bg: 'rgba(74,222,128,0.1)', label: 'ONLINE', pulse: true },
  disconnected: { color: '#6b7280', bg: 'rgba(107,114,128,0.1)', label: 'OFFLINE', pulse: false },
  connecting:   { color: '#fbbf24', bg: 'rgba(251,191,36,0.1)', label: 'CONNECTING', pulse: true },
  reconnecting: { color: '#f97316', bg: 'rgba(249,115,22,0.1)', label: 'RECONNECTING', pulse: true },
  kicked:       { color: '#f87171', bg: 'rgba(248,113,113,0.1)', label: 'KICKED', pulse: false },
  error:        { color: '#ef4444', bg: 'rgba(239,68,68,0.1)', label: 'ERROR', pulse: false }
};

function formatUptime(ms) {
  if (!ms) return '0s';
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ${h % 24}h`;
  if (h > 0) return `${h}h ${m % 60}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

export default function BotCard({ bot, onSelect, selected }) {
  const { startBot, stopBot, removeBot } = useSocket();
  const [uptime, setUptime] = useState(bot.uptime || 0);
  const timerRef = useRef(null);

  const status = STATUS_CONFIG[bot.status] || STATUS_CONFIG.disconnected;

  useEffect(() => {
    if (bot.status === 'connected') {
      timerRef.current = setInterval(() => setUptime(u => u + 1000), 1000);
    } else {
      clearInterval(timerRef.current);
      setUptime(0);
    }
    return () => clearInterval(timerRef.current);
  }, [bot.status]);

  return (
    <div
      onClick={() => onSelect(bot.id)}
      style={{
        background: selected ? 'rgba(74,222,128,0.05)' : '#0d1117',
        border: `1px solid ${selected ? '#4ade80' : '#21262d'}`,
        borderRadius: '12px',
        padding: '20px',
        cursor: 'pointer',
        transition: 'all 0.2s ease',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {/* Glow effect on selected */}
      {selected && (
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '12px',
          background: 'radial-gradient(circle at 50% 0%, rgba(74,222,128,0.08), transparent 70%)',
          pointerEvents: 'none'
        }} />
      )}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '14px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              background: status.color,
              boxShadow: status.pulse ? `0 0 8px ${status.color}` : 'none',
              animation: status.pulse ? 'pulse 2s infinite' : 'none'
            }} />
            <span style={{ color: '#c9d1d9', fontSize: '15px', fontWeight: 600, fontFamily: 'Space Grotesk' }}>
              {bot.name || bot.username}
            </span>
          </div>
          <span style={{
            fontSize: '11px', fontWeight: 600, letterSpacing: '0.1em',
            color: status.color, background: status.bg,
            padding: '2px 8px', borderRadius: '4px'
          }}>
            {status.label}
          </span>
        </div>

        {/* Minecraft icon */}
        <div style={{
          width: '40px', height: '40px', borderRadius: '8px',
          background: 'linear-gradient(135deg, #4d9f0c, #2d5a06)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '20px', flexShrink: 0
        }}>
          🎮
        </div>
      </div>

      {/* Server info */}
      <div style={{ marginBottom: '14px' }}>
        <div style={{ color: '#8b949e', fontSize: '12px', fontFamily: 'JetBrains Mono' }}>
          {bot.host}:{bot.port}
        </div>
        <div style={{ color: '#6e7681', fontSize: '11px', marginTop: '2px' }}>
          v{bot.version || 'auto'} · {bot.auth === 'microsoft' ? '🔑 Premium' : '🔓 Offline'}
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', marginBottom: '14px' }}>
        {[
          { label: 'PING', value: bot.ping ? `${bot.ping}ms` : '--' },
          { label: 'PLAYERS', value: bot.playerCount ?? '--' },
          { label: 'UPTIME', value: formatUptime(uptime) }
        ].map(({ label, value }) => (
          <div key={label} style={{
            background: '#161b22', borderRadius: '8px', padding: '8px',
            textAlign: 'center', border: '1px solid #21262d'
          }}>
            <div style={{ color: '#4ade80', fontSize: '13px', fontWeight: 700, fontFamily: 'JetBrains Mono' }}>{value}</div>
            <div style={{ color: '#6e7681', fontSize: '9px', letterSpacing: '0.08em', marginTop: '2px' }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Health bar */}
      {bot.status === 'connected' && bot.health !== undefined && (
        <div style={{ marginBottom: '14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
            <span style={{ color: '#6e7681', fontSize: '10px' }}>❤️ Health</span>
            <span style={{ color: '#f87171', fontSize: '10px', fontFamily: 'JetBrains Mono' }}>{Math.round(bot.health || 0)}/20</span>
          </div>
          <div style={{ height: '4px', background: '#21262d', borderRadius: '2px' }}>
            <div style={{
              width: `${((bot.health || 0) / 20) * 100}%`,
              height: '100%', background: '#f87171', borderRadius: '2px',
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: '8px' }} onClick={e => e.stopPropagation()}>
        {bot.status === 'connected' ? (
          <button onClick={() => stopBot(bot.id)} style={{
            flex: 1, padding: '7px', background: 'rgba(248,113,113,0.1)',
            border: '1px solid rgba(248,113,113,0.3)', borderRadius: '8px',
            color: '#f87171', fontSize: '12px', fontWeight: 600, cursor: 'pointer'
          }}>⏹ Stop</button>
        ) : (
          <button onClick={() => startBot(bot.id)} style={{
            flex: 1, padding: '7px', background: 'rgba(74,222,128,0.1)',
            border: '1px solid rgba(74,222,128,0.3)', borderRadius: '8px',
            color: '#4ade80', fontSize: '12px', fontWeight: 600, cursor: 'pointer'
          }}>▶ Start</button>
        )}
        <button onClick={() => removeBot(bot.id)} style={{
          padding: '7px 12px', background: 'rgba(239,68,68,0.08)',
          border: '1px solid rgba(239,68,68,0.2)', borderRadius: '8px',
          color: '#6e7681', fontSize: '12px', cursor: 'pointer'
        }}>🗑</button>
      </div>

      <style>{`@keyframes pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }`}</style>
    </div>
  );
}
