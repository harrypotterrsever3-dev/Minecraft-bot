import { useState } from 'react';
import { useSocket } from '../../hooks/useSocket';

export default function AddBotModal({ onClose }) {
  const { addBot, versions } = useSocket();
  const [form, setForm] = useState({
    name: '', username: '', host: '', port: '25565',
    version: '', auth: 'offline', autoStart: true,
    registerPassword: '', loginPassword: ''
  });
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username || !form.host) return;
    setLoading(true);
    addBot({
      ...form,
      port: parseInt(form.port) || 25565,
      name: form.name || form.username
    });
    setTimeout(() => { setLoading(false); onClose(); }, 500);
  };

  const inputStyle = {
    width: '100%', background: '#0d1117', border: '1px solid #30363d',
    borderRadius: '8px', padding: '10px 14px', color: '#c9d1d9',
    fontSize: '13px', outline: 'none', fontFamily: 'Space Grotesk',
    transition: 'border-color 0.2s', boxSizing: 'border-box'
  };
  const labelStyle = { color: '#8b949e', fontSize: '12px', fontWeight: 600, marginBottom: '6px', display: 'block' };

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 1000, padding: '16px'
    }}>
      <div style={{
        background: '#161b22', border: '1px solid #30363d', borderRadius: '16px',
        padding: '28px', width: '100%', maxWidth: '520px',
        maxHeight: '90vh', overflowY: 'auto',
        boxShadow: '0 0 60px rgba(74,222,128,0.1)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h2 style={{ color: '#c9d1d9', margin: 0, fontSize: '20px', fontWeight: 700 }}>
            🤖 Add New Bot
          </h2>
          <button onClick={onClose} style={{
            background: 'none', border: 'none', color: '#6e7681',
            fontSize: '20px', cursor: 'pointer', padding: '4px'
          }}>✕</button>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div>
              <label style={labelStyle}>Display Name</label>
              <input value={form.name} onChange={e => set('name', e.target.value)}
                placeholder="My Bot" style={inputStyle}
                onFocus={e => e.target.style.borderColor = '#4ade80'}
                onBlur={e => e.target.style.borderColor = '#30363d'} />
            </div>
            <div>
              <label style={labelStyle}>Username *</label>
              <input value={form.username} onChange={e => set('username', e.target.value)}
                placeholder="Steve" required style={inputStyle}
                onFocus={e => e.target.style.borderColor = '#4ade80'}
                onBlur={e => e.target.style.borderColor = '#30363d'} />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div>
              <label style={labelStyle}>Server IP *</label>
              <input value={form.host} onChange={e => set('host', e.target.value)}
                placeholder="play.example.com" required style={inputStyle}
                onFocus={e => e.target.style.borderColor = '#4ade80'}
                onBlur={e => e.target.style.borderColor = '#30363d'} />
            </div>
            <div>
              <label style={labelStyle}>Port</label>
              <input value={form.port} onChange={e => set('port', e.target.value)}
                placeholder="25565" type="number" style={inputStyle}
                onFocus={e => e.target.style.borderColor = '#4ade80'}
                onBlur={e => e.target.style.borderColor = '#30363d'} />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div>
              <label style={labelStyle}>Minecraft Version</label>
              <select value={form.version} onChange={e => set('version', e.target.value)}
                style={{ ...inputStyle, cursor: 'pointer' }}>
                <option value="">Auto Detect</option>
                {[...(versions || [])].reverse().map(v => (
                  <option key={v} value={v}>{v}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Auth Mode</label>
              <select value={form.auth} onChange={e => set('auth', e.target.value)}
                style={{ ...inputStyle, cursor: 'pointer' }}>
                <option value="offline">🔓 Offline/Cracked</option>
                <option value="microsoft">🔑 Microsoft (Premium)</option>
              </select>
            </div>
          </div>

          {/* Auto login/register */}
          <div style={{
            background: '#0d1117', border: '1px solid #21262d',
            borderRadius: '10px', padding: '14px', marginBottom: '16px'
          }}>
            <div style={{ color: '#8b949e', fontSize: '12px', fontWeight: 600, marginBottom: '10px' }}>
              🔐 Auto Commands (optional)
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div>
                <label style={{ ...labelStyle, color: '#6e7681' }}>/register password</label>
                <input value={form.registerPassword} onChange={e => set('registerPassword', e.target.value)}
                  placeholder="leave empty to skip" type="password" style={{ ...inputStyle, fontSize: '12px' }}
                  onFocus={e => e.target.style.borderColor = '#4ade80'}
                  onBlur={e => e.target.style.borderColor = '#30363d'} />
              </div>
              <div>
                <label style={{ ...labelStyle, color: '#6e7681' }}>/login password</label>
                <input value={form.loginPassword} onChange={e => set('loginPassword', e.target.value)}
                  placeholder="leave empty to skip" type="password" style={{ ...inputStyle, fontSize: '12px' }}
                  onFocus={e => e.target.style.borderColor = '#4ade80'}
                  onBlur={e => e.target.style.borderColor = '#30363d'} />
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
            <div
              onClick={() => set('autoStart', !form.autoStart)}
              style={{
                width: '40px', height: '22px', borderRadius: '11px', cursor: 'pointer',
                background: form.autoStart ? '#4ade80' : '#21262d', transition: 'background 0.2s',
                position: 'relative', flexShrink: 0
              }}
            >
              <div style={{
                width: '18px', height: '18px', borderRadius: '50%', background: '#fff',
                position: 'absolute', top: '2px', transition: 'left 0.2s',
                left: form.autoStart ? '20px' : '2px'
              }} />
            </div>
            <span style={{ color: '#8b949e', fontSize: '13px' }}>Auto-start after adding</span>
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            <button type="button" onClick={onClose} style={{
              flex: 1, padding: '11px', background: 'transparent',
              border: '1px solid #30363d', borderRadius: '8px',
              color: '#6e7681', fontSize: '14px', cursor: 'pointer', fontFamily: 'Space Grotesk'
            }}>
              Cancel
            </button>
            <button type="submit" disabled={loading} style={{
              flex: 2, padding: '11px',
              background: 'linear-gradient(135deg, #4ade80, #22c55e)',
              border: 'none', borderRadius: '8px', color: '#0a0e1a',
              fontSize: '14px', fontWeight: 700, cursor: 'pointer',
              fontFamily: 'Space Grotesk', opacity: loading ? 0.7 : 1
            }}>
              {loading ? '⏳ Adding...' : '🤖 Add Bot'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
