import { useState, useEffect, useRef } from 'react';
import { useSocket } from '../../hooks/useSocket';

export default function ChatPanel({ botId }) {
  const { sendChat, addChatListener, getBotHistory } = useSocket();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [filter, setFilter] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    if (!botId) return;
    // Load history
    getBotHistory(botId).then(data => {
      if (data?.chat) setMessages(data.chat);
    }).catch(() => {});

    const unsub = addChatListener(botId, (entry) => {
      setMessages(prev => {
        const next = [...prev, entry];
        return next.length > 300 ? next.slice(-300) : next;
      });
    });
    return unsub;
  }, [botId, addChatListener, getBotHistory]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim() || !botId) return;
    sendChat(botId, input.trim());
    setInput('');
  };

  const filtered = filter
    ? messages.filter(m => m.message?.toLowerCase().includes(filter.toLowerCase()) ||
        m.username?.toLowerCase().includes(filter.toLowerCase()))
    : messages;

  const getColor = (type, username) => {
    if (type === 'system') return '#8b949e';
    const colors = ['#4ade80', '#60a5fa', '#f472b6', '#fb923c', '#a78bfa', '#34d399'];
    let hash = 0;
    for (let c of (username || '')) hash = c.charCodeAt(0) + ((hash << 5) - hash);
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0d1117' }}>
      {/* Header */}
      <div style={{
        padding: '12px 16px', borderBottom: '1px solid #21262d',
        display: 'flex', alignItems: 'center', gap: '12px', flexShrink: 0
      }}>
        <span style={{ color: '#4ade80', fontSize: '16px' }}>💬</span>
        <span style={{ color: '#c9d1d9', fontSize: '14px', fontWeight: 600 }}>Chat</span>
        <span style={{
          background: 'rgba(74,222,128,0.15)', color: '#4ade80',
          fontSize: '11px', padding: '2px 8px', borderRadius: '10px', marginLeft: 'auto'
        }}>{messages.length}</span>
        <input
          value={filter}
          onChange={e => setFilter(e.target.value)}
          placeholder="Filter..."
          style={{
            background: '#161b22', border: '1px solid #30363d', borderRadius: '6px',
            padding: '4px 10px', color: '#c9d1d9', fontSize: '12px', width: '120px', outline: 'none'
          }}
        />
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
        {!botId && (
          <div style={{ color: '#6e7681', textAlign: 'center', marginTop: '40px', fontSize: '14px' }}>
            Select a bot to view chat
          </div>
        )}
        {filtered.map((msg, i) => (
          <div key={i} style={{
            display: 'flex', gap: '8px', alignItems: 'flex-start',
            animation: 'fadeIn 0.2s ease'
          }}>
            <span style={{
              color: '#4d5566', fontSize: '10px', fontFamily: 'JetBrains Mono',
              flexShrink: 0, marginTop: '2px', minWidth: '50px'
            }}>
              {new Date(msg.time).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
            {msg.type !== 'system' && (
              <span style={{
                color: getColor(msg.type, msg.username),
                fontSize: '13px', fontWeight: 600, flexShrink: 0
              }}>
                {msg.username}
              </span>
            )}
            <span style={{
              color: msg.type === 'system' ? '#6e7681' : '#c9d1d9',
              fontSize: '13px', wordBreak: 'break-word', lineHeight: 1.5,
              fontStyle: msg.type === 'system' ? 'italic' : 'normal'
            }}>
              {msg.type !== 'system' && ': '}{msg.message}
            </span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} style={{
        padding: '12px 16px', borderTop: '1px solid #21262d',
        display: 'flex', gap: '8px', flexShrink: 0
      }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={botId ? "Send a message or /command..." : "Select a bot first"}
          disabled={!botId}
          style={{
            flex: 1, background: '#161b22', border: '1px solid #30363d',
            borderRadius: '8px', padding: '9px 14px', color: '#c9d1d9',
            fontSize: '13px', fontFamily: 'JetBrains Mono', outline: 'none',
            transition: 'border-color 0.2s'
          }}
          onFocus={e => e.target.style.borderColor = '#4ade80'}
          onBlur={e => e.target.style.borderColor = '#30363d'}
        />
        <button
          type="submit"
          disabled={!botId || !input.trim()}
          style={{
            background: 'linear-gradient(135deg, #4ade80, #22c55e)',
            border: 'none', borderRadius: '8px', padding: '9px 16px',
            color: '#0a0e1a', fontWeight: 700, fontSize: '13px',
            cursor: botId && input.trim() ? 'pointer' : 'not-allowed',
            opacity: botId && input.trim() ? 1 : 0.4,
            transition: 'opacity 0.2s'
          }}
        >
          Send
        </button>
      </form>

      <style>{`@keyframes fadeIn { from { opacity:0; transform:translateY(4px) } to { opacity:1; transform:none } }`}</style>
    </div>
  );
}
