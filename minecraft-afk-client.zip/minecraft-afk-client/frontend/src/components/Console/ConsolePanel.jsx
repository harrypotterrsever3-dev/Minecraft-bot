import { useState, useEffect, useRef } from 'react';
import { useSocket } from '../../hooks/useSocket';

const LEVEL_COLORS = {
  info:  '#4ade80',
  warn:  '#fbbf24',
  error: '#f87171',
  debug: '#60a5fa'
};

export default function ConsolePanel({ botId }) {
  const { addLogListener, getBotHistory } = useSocket();
  const [logs, setLogs] = useState([]);
  const [filter, setFilter] = useState('all');
  const [paused, setPaused] = useState(false);
  const bottomRef = useRef(null);
  const pausedRef = useRef(false);
  pausedRef.current = paused;

  useEffect(() => {
    if (!botId) return;
    getBotHistory(botId).then(data => {
      if (data?.console) setLogs(data.console);
    }).catch(() => {});

    const unsub = addLogListener(botId, (entry) => {
      if (!pausedRef.current) {
        setLogs(prev => {
          const next = [...prev, entry];
          return next.length > 500 ? next.slice(-500) : next;
        });
      }
    });
    return unsub;
  }, [botId, addLogListener, getBotHistory]);

  useEffect(() => {
    if (!paused) bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, paused]);

  const filtered = filter === 'all' ? logs : logs.filter(l => l.level === filter);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0d1117' }}>
      {/* Header */}
      <div style={{
        padding: '12px 16px', borderBottom: '1px solid #21262d',
        display: 'flex', alignItems: 'center', gap: '12px', flexShrink: 0, flexWrap: 'wrap'
      }}>
        <span style={{ color: '#4ade80', fontSize: '16px' }}>🖥</span>
        <span style={{ color: '#c9d1d9', fontSize: '14px', fontWeight: 600 }}>Console</span>

        {/* Level filter tabs */}
        <div style={{ display: 'flex', gap: '4px', marginLeft: 'auto' }}>
          {['all', 'info', 'warn', 'error'].map(level => (
            <button
              key={level}
              onClick={() => setFilter(level)}
              style={{
                padding: '3px 10px', borderRadius: '6px', fontSize: '11px',
                fontWeight: 600, cursor: 'pointer', border: 'none',
                background: filter === level ? (LEVEL_COLORS[level] || '#4ade80') : '#161b22',
                color: filter === level ? '#0a0e1a' : '#6e7681',
                transition: 'all 0.15s'
              }}
            >
              {level.toUpperCase()}
            </button>
          ))}
        </div>

        <button
          onClick={() => setPaused(p => !p)}
          style={{
            padding: '3px 10px', borderRadius: '6px', fontSize: '11px',
            fontWeight: 600, cursor: 'pointer', border: '1px solid #30363d',
            background: paused ? 'rgba(251,191,36,0.15)' : '#161b22',
            color: paused ? '#fbbf24' : '#6e7681'
          }}
        >
          {paused ? '▶ Resume' : '⏸ Pause'}
        </button>

        <button
          onClick={() => setLogs([])}
          style={{
            padding: '3px 10px', borderRadius: '6px', fontSize: '11px',
            cursor: 'pointer', border: '1px solid #30363d',
            background: '#161b22', color: '#6e7681'
          }}
        >
          🗑 Clear
        </button>
      </div>

      {/* Console output */}
      <div style={{
        flex: 1, overflowY: 'auto', padding: '12px 16px',
        fontFamily: 'JetBrains Mono', fontSize: '12px',
        display: 'flex', flexDirection: 'column', gap: '2px'
      }}>
        {!botId && (
          <div style={{ color: '#6e7681', textAlign: 'center', marginTop: '40px', fontFamily: 'Space Grotesk' }}>
            Select a bot to view console logs
          </div>
        )}
        {filtered.length === 0 && botId && (
          <div style={{ color: '#6e7681', textAlign: 'center', marginTop: '40px', fontFamily: 'Space Grotesk' }}>
            No logs yet...
          </div>
        )}
        {filtered.map((log, i) => (
          <div key={i} style={{
            display: 'flex', gap: '10px', alignItems: 'flex-start',
            padding: '2px 0',
            borderBottom: '1px solid rgba(33,38,45,0.4)'
          }}>
            <span style={{ color: '#4d5566', flexShrink: 0, minWidth: '75px' }}>
              {new Date(log.time).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
            <span style={{
              color: LEVEL_COLORS[log.level] || '#c9d1d9',
              flexShrink: 0, width: '40px', fontWeight: 700,
              fontSize: '10px', marginTop: '1px'
            }}>
              {log.level?.toUpperCase()}
            </span>
            <span style={{ color: '#c9d1d9', wordBreak: 'break-all', lineHeight: 1.6 }}>
              {log.message}
            </span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {paused && (
        <div style={{
          padding: '6px', textAlign: 'center', background: 'rgba(251,191,36,0.1)',
          borderTop: '1px solid rgba(251,191,36,0.2)', color: '#fbbf24', fontSize: '11px'
        }}>
          ⏸ Console paused — new logs buffering
        </div>
      )}
    </div>
  );
}
