import { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { SocketProvider, useSocket } from './hooks/useSocket';
import BotCard from './components/BotCard/BotCard';
import AddBotModal from './components/BotCard/AddBotModal';
import ChatPanel from './components/Chat/ChatPanel';
import ConsolePanel from './components/Console/ConsolePanel';
import StatsPanel from './components/Stats/StatsPanel';
import SettingsPanel from './components/Stats/SettingsPanel';

function Dashboard() {
  const { bots, connected, systemStats, startBot, stopBot } = useSocket();
  const [selectedBotId, setSelectedBotId] = useState(null);
  const [activeTab, setActiveTab] = useState('chat');
  const [showAddModal, setShowAddModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const selectedBot = bots.find(b => b.id === selectedBotId);
  const connectedBots = bots.filter(b => b.status === 'connected').length;

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#0a0e1a', overflow: 'hidden', flexDirection: 'column' }}>
      {/* Top Nav */}
      <header style={{
        background: '#0d1117', borderBottom: '1px solid #21262d',
        padding: '0 20px', height: '56px', display: 'flex',
        alignItems: 'center', gap: '16px', flexShrink: 0, zIndex: 10
      }}>
        <button onClick={() => setSidebarOpen(o => !o)} style={{
          background: 'none', border: 'none', color: '#6e7681', fontSize: '18px',
          cursor: 'pointer', padding: '4px', lineHeight: 1
        }}>☰</button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '22px' }}>⛏</span>
          <span style={{ color: '#4ade80', fontWeight: 700, fontSize: '16px', letterSpacing: '-0.3px' }}>MC AFK</span>
          <span style={{ color: '#6e7681', fontSize: '14px', fontWeight: 400 }}>Client</span>
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '16px' }}>
          {/* System stats */}
          {systemStats.memory && (
            <div style={{ display: 'flex', gap: '12px' }}>
              <Chip label="CPU" value={`${systemStats.cpu}%`} color={+systemStats.cpu > 80 ? '#f87171' : '#4ade80'} />
              <Chip label="RAM" value={`${systemStats.memory.used}MB`} color="#60a5fa" />
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              background: connected ? '#4ade80' : '#f87171',
              boxShadow: connected ? '0 0 6px #4ade80' : '0 0 6px #f87171'
            }} />
            <span style={{ color: '#8b949e', fontSize: '12px' }}>{connected ? 'Connected' : 'Offline'}</span>
          </div>

          <div style={{
            background: 'rgba(74,222,128,0.12)', border: '1px solid rgba(74,222,128,0.25)',
            borderRadius: '20px', padding: '3px 12px',
            color: '#4ade80', fontSize: '12px', fontWeight: 600
          }}>
            {connectedBots}/{bots.length} Online
          </div>
        </div>
      </header>

      {/* Body */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Sidebar */}
        <aside style={{
          width: sidebarOpen ? '300px' : '0',
          transition: 'width 0.25s ease',
          overflow: 'hidden', flexShrink: 0,
          borderRight: '1px solid #21262d',
          display: 'flex', flexDirection: 'column',
          background: '#0d1117'
        }}>
          <div style={{ padding: '16px', width: '300px' }}>
            {/* Add bot button */}
            <button
              onClick={() => setShowAddModal(true)}
              style={{
                width: '100%', padding: '10px',
                background: 'linear-gradient(135deg, rgba(74,222,128,0.15), rgba(74,222,128,0.05))',
                border: '1px dashed rgba(74,222,128,0.4)', borderRadius: '10px',
                color: '#4ade80', fontSize: '13px', fontWeight: 600,
                cursor: 'pointer', marginBottom: '14px', transition: 'all 0.2s',
                fontFamily: 'Space Grotesk'
              }}
              onMouseEnter={e => e.target.style.background = 'rgba(74,222,128,0.15)'}
              onMouseLeave={e => e.target.style.background = 'linear-gradient(135deg, rgba(74,222,128,0.15), rgba(74,222,128,0.05))'}
            >
              + Add Bot
            </button>

            {/* Bot list */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', overflowY: 'auto', maxHeight: 'calc(100vh - 180px)' }}>
              {bots.length === 0 ? (
                <div style={{ textAlign: 'center', color: '#6e7681', fontSize: '13px', padding: '30px 10px' }}>
                  <div style={{ fontSize: '32px', marginBottom: '10px' }}>🤖</div>
                  No bots yet.<br />Add one to get started.
                </div>
              ) : (
                bots.map(bot => (
                  <BotCard
                    key={bot.id}
                    bot={bot}
                    selected={selectedBotId === bot.id}
                    onSelect={setSelectedBotId}
                  />
                ))
              )}
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Tabs */}
          <div style={{
            display: 'flex', gap: '2px', padding: '8px 16px',
            borderBottom: '1px solid #21262d', background: '#0d1117', flexShrink: 0,
            overflowX: 'auto'
          }}>
            {[
              { id: 'chat', icon: '💬', label: 'Chat' },
              { id: 'console', icon: '🖥', label: 'Console' },
              { id: 'stats', icon: '📊', label: 'Stats' },
              { id: 'settings', icon: '⚙️', label: 'Settings' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: '7px 16px', borderRadius: '8px', cursor: 'pointer',
                  border: 'none', fontFamily: 'Space Grotesk', fontSize: '13px',
                  fontWeight: activeTab === tab.id ? 600 : 400,
                  background: activeTab === tab.id ? 'rgba(74,222,128,0.12)' : 'transparent',
                  color: activeTab === tab.id ? '#4ade80' : '#6e7681',
                  transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: '6px',
                  whiteSpace: 'nowrap'
                }}
              >
                <span>{tab.icon}</span> {tab.label}
              </button>
            ))}

            {/* Selected bot info in tab bar */}
            {selectedBot && (
              <div style={{
                marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '8px',
                padding: '4px 12px', background: '#161b22', borderRadius: '8px',
                border: '1px solid #21262d'
              }}>
                <div style={{
                  width: '6px', height: '6px', borderRadius: '50%',
                  background: selectedBot.status === 'connected' ? '#4ade80' : '#f87171'
                }} />
                <span style={{ color: '#c9d1d9', fontSize: '12px', fontFamily: 'JetBrains Mono' }}>
                  {selectedBot.name || selectedBot.username}
                </span>
                <span style={{ color: '#6e7681', fontSize: '11px' }}>
                  {selectedBot.host}
                </span>
              </div>
            )}
          </div>

          {/* Tab content */}
          <div style={{ flex: 1, overflow: 'hidden' }}>
            {activeTab === 'chat' && <ChatPanel botId={selectedBotId} />}
            {activeTab === 'console' && <ConsolePanel botId={selectedBotId} />}
            {activeTab === 'stats' && <div style={{ overflowY: 'auto', height: '100%' }}><StatsPanel bot={selectedBot} /></div>}
            {activeTab === 'settings' && <div style={{ overflowY: 'auto', height: '100%' }}><SettingsPanel /></div>}
          </div>
        </main>
      </div>

      {showAddModal && <AddBotModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
}

function Chip({ label, value, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
      <span style={{ color: '#6e7681', fontSize: '10px' }}>{label}</span>
      <span style={{ color, fontSize: '11px', fontFamily: 'JetBrains Mono', fontWeight: 600 }}>{value}</span>
    </div>
  );
}

export default function App() {
  return (
    <SocketProvider>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: { background: '#161b22', color: '#c9d1d9', border: '1px solid #30363d', fontSize: '13px' },
          duration: 3000
        }}
      />
      <Dashboard />
    </SocketProvider>
  );
}
