import { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { io } from 'socket.io-client';
import toast from 'react-hot-toast';

const SocketContext = createContext(null);

const SERVER_URL = process.env.REACT_APP_SERVER_URL || '';

export function SocketProvider({ children }) {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [bots, setBots] = useState([]);
  const [settings, setSettings] = useState({});
  const [versions, setVersions] = useState([]);
  const [systemStats, setSystemStats] = useState({});
  const chatListeners = useRef({});
  const logListeners = useRef({});

  useEffect(() => {
    const s = io(SERVER_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 2000,
      reconnectionAttempts: Infinity
    });

    s.on('connect', () => {
      setConnected(true);
      toast.success('Connected to server', { id: 'conn', icon: '🔌' });
    });

    s.on('disconnect', () => {
      setConnected(false);
      toast.error('Disconnected from server', { id: 'conn' });
    });

    s.on('init', ({ bots, settings, versions }) => {
      setBots(bots);
      setSettings(settings);
      setVersions(versions);
    });

    s.on('botAdded', (bot) => {
      setBots(prev => [...prev, bot]);
      toast.success(`Bot added: ${bot.username}`, { icon: '🤖' });
    });

    s.on('botRemoved', ({ botId }) => {
      setBots(prev => prev.filter(b => b.id !== botId));
      toast.success('Bot removed');
    });

    s.on('botStats', (botStatus) => {
      setBots(prev => prev.map(b => b.id === botStatus.id ? { ...b, ...botStatus } : b));
    });

    s.on('botStatusChange', ({ botId, status, reason, error }) => {
      setBots(prev => prev.map(b => b.id === botId ? { ...b, status } : b));
      const icons = { connected: '✅', disconnected: '🔌', kicked: '⚠️', error: '❌', reconnecting: '🔄' };
      if (status === 'connected') toast.success(`Bot connected!`, { icon: icons[status] });
      else if (status === 'kicked') toast.error(`Bot kicked: ${reason}`, { icon: icons[status] });
      else if (status === 'error') toast.error(`Bot error: ${error}`, { icon: icons[status] });
    });

    s.on('botPlayersUpdate', ({ botId, players, count }) => {
      setBots(prev => prev.map(b => b.id === botId ? { ...b, players, playerCount: count } : b));
    });

    s.on('botStatsUpdate', ({ botId, health, food, ping }) => {
      setBots(prev => prev.map(b => b.id === botId ? { ...b, health, food, ping } : b));
    });

    s.on('botChat', (entry) => {
      const listeners = chatListeners.current[entry.botId] || [];
      listeners.forEach(fn => fn(entry));
    });

    s.on('botLog', (entry) => {
      const listeners = logListeners.current[entry.botId] || [];
      listeners.forEach(fn => fn(entry));
    });

    s.on('systemStats', setSystemStats);

    s.on('settingsUpdated', setSettings);

    s.on('error', ({ message }) => toast.error(message));

    setSocket(s);
    return () => s.disconnect();
  }, []);

  const addChatListener = useCallback((botId, fn) => {
    chatListeners.current[botId] = [...(chatListeners.current[botId] || []), fn];
    return () => {
      chatListeners.current[botId] = (chatListeners.current[botId] || []).filter(f => f !== fn);
    };
  }, []);

  const addLogListener = useCallback((botId, fn) => {
    logListeners.current[botId] = [...(logListeners.current[botId] || []), fn];
    return () => {
      logListeners.current[botId] = (logListeners.current[botId] || []).filter(f => f !== fn);
    };
  }, []);

  const startBot = useCallback((botId) => socket?.emit('startBot', { botId }), [socket]);
  const stopBot = useCallback((botId) => socket?.emit('stopBot', { botId }), [socket]);
  const removeBot = useCallback((botId) => socket?.emit('removeBot', { botId }), [socket]);
  const sendChat = useCallback((botId, message) => socket?.emit('sendChat', { botId, message }), [socket]);
  const addBot = useCallback((config) => socket?.emit('addBot', config), [socket]);
  const updateSettings = useCallback((s) => socket?.emit('updateSettings', s), [socket]);
  const getBotHistory = useCallback((botId) => {
    return new Promise((resolve) => {
      socket?.emit('getBotHistory', { botId });
      socket?.once('botHistory', (data) => { if (data.botId === botId) resolve(data); });
    });
  }, [socket]);

  return (
    <SocketContext.Provider value={{
      socket, connected, bots, settings, versions, systemStats,
      startBot, stopBot, removeBot, sendChat, addBot, updateSettings,
      getBotHistory, addChatListener, addLogListener, setBots, setSettings
    }}>
      {children}
    </SocketContext.Provider>
  );
}

export const useSocket = () => useContext(SocketContext);
