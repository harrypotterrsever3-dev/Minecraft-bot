const { v4: uuidv4 } = require('uuid');
const { BotInstance, SUPPORTED_VERSIONS } = require('./BotInstance');
const { readConfig, saveBotConfig, removeBotConfig, updateSettings } = require('../utils/configManager');
const logger = require('../utils/logger');

class BotManager {
  constructor(io) {
    this.io = io;
    this.bots = new Map();
    this.settings = {};
    this._loadFromConfig();
  }

  _loadFromConfig() {
    const config = readConfig();
    this.settings = config.settings;
    logger.info(`Loaded ${config.bots.length} bot(s) from config`);
    for (const botConfig of config.bots) {
      if (botConfig.autoStart) {
        this.addBot(botConfig, false);
        setTimeout(() => this.startBot(botConfig.id), 2000);
      } else {
        this.addBot(botConfig, false);
      }
    }
  }

  _refreshSettings() {
    const config = readConfig();
    this.settings = config.settings;
  }

  addBot(botConfig, saveToConfig = true) {
    const id = botConfig.id || uuidv4();
    const config = { id, ...botConfig };

    if (this.bots.has(id)) {
      throw new Error(`Bot with ID ${id} already exists`);
    }

    const bot = new BotInstance(config, this.settings);
    this._bindBotEvents(bot);
    this.bots.set(id, bot);

    if (saveToConfig) saveBotConfig(id, config);

    logger.info(`Bot added: ${config.username}@${config.host}:${config.port}`);
    this.io.emit('botAdded', bot.getStatus());
    return bot;
  }

  _bindBotEvents(bot) {
    bot.on('statusChange', (data) => {
      this.io.emit('botStatusChange', data);
      this.io.emit('botStats', bot.getStatus());
    });

    bot.on('log', (entry) => {
      this.io.emit('botLog', entry);
    });

    bot.on('chat', (entry) => {
      this.io.emit('botChat', entry);
    });

    bot.on('playersUpdate', (data) => {
      this.io.emit('botPlayersUpdate', data);
    });

    bot.on('statsUpdate', (data) => {
      this.io.emit('botStatsUpdate', data);
    });
  }

  startBot(id) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    bot.connect();
    return bot.getStatus();
  }

  stopBot(id) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    bot.disconnect();
    return bot.getStatus();
  }

  removeBot(id) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    bot.disconnect();
    this.bots.delete(id);
    removeBotConfig(id);
    this.io.emit('botRemoved', { botId: id });
    logger.info(`Bot removed: ${id}`);
  }

  sendMessage(id, message) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    return bot.sendChat(message);
  }

  updateBotConfig(id, newConfig) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    const wasConnected = bot.status === 'connected';
    if (wasConnected) bot.disconnect();
    bot.config = { ...bot.config, ...newConfig };
    saveBotConfig(id, bot.config);
    if (wasConnected) setTimeout(() => bot.connect(), 1000);
    return bot.getStatus();
  }

  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    updateSettings(newSettings);
    this.bots.forEach(bot => { bot.settings = this.settings; });
    return this.settings;
  }

  getAllBots() {
    return Array.from(this.bots.values()).map(b => b.getStatus());
  }

  getBot(id) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    return bot;
  }

  getBotHistory(id) {
    const bot = this.bots.get(id);
    if (!bot) throw new Error(`Bot ${id} not found`);
    return bot.getHistory();
  }

  startAll() { this.bots.forEach(b => { if (b.status === 'disconnected') b.connect(); }); }
  stopAll() { this.bots.forEach(b => b.disconnect()); }

  getSupportedVersions() { return SUPPORTED_VERSIONS; }
  getSettings() { return this.settings; }
}

module.exports = BotManager;
