const mineflayer = require('mineflayer');
const { EventEmitter } = require('events');
const logger = require('../utils/logger');

const SUPPORTED_VERSIONS = [
  '1.8.9', '1.9.4', '1.10.2', '1.11.2', '1.12.2',
  '1.13.2', '1.14.4', '1.15.2', '1.16.5', '1.17.1',
  '1.18.2', '1.19.4', '1.20.1', '1.20.4', '1.20.6',
  '1.21.1', '1.21.4'
];

class BotInstance extends EventEmitter {
  constructor(config, globalSettings) {
    super();
    this.id = config.id;
    this.config = config;
    this.settings = globalSettings;
    this.bot = null;
    this.status = 'disconnected';
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this.afkTimer = null;
    this.chatHistory = [];
    this.consoleHistory = [];
    this.ping = 0;
    this.playerCount = 0;
    this.players = [];
    this.startTime = null;
    this.lastError = null;
    this.isConnecting = false;
    this.shouldReconnect = false;
    this.stats = {
      totalUptime: 0,
      reconnects: 0,
      messagesSent: 0,
      disconnectedAt: null,
      connectedAt: null
    };
  }

  log(level, message) {
    const entry = {
      time: new Date().toISOString(),
      level,
      message,
      botId: this.id
    };
    this.consoleHistory.push(entry);
    if (this.consoleHistory.length > 500) this.consoleHistory.shift();
    logger[level]?.(message, { botId: this.id }) ?? logger.info(message);
    this.emit('log', entry);
  }

  connect() {
    if (this.isConnecting || this.status === 'connected') return;
    this.isConnecting = true;
    this.shouldReconnect = true;
    this.log('info', `Connecting to ${this.config.host}:${this.config.port} as ${this.config.username}...`);
    this.emit('statusChange', { status: 'connecting', botId: this.id });

    try {
      const botOptions = {
        host: this.config.host,
        port: parseInt(this.config.port) || 25565,
        username: this.config.username,
        version: this.config.version || false,
        auth: this.config.auth || 'offline',
        hideErrors: false,
        checkTimeoutInterval: 30000,
        physicsEnabled: true
      };

      if (this.config.auth === 'microsoft') {
        botOptions.auth = 'microsoft';
      }

      this.bot = mineflayer.createBot(botOptions);
      this._attachEvents();
    } catch (err) {
      this.isConnecting = false;
      this.status = 'error';
      this.lastError = err.message;
      this.log('error', `Failed to create bot: ${err.message}`);
      this.emit('statusChange', { status: 'error', error: err.message, botId: this.id });
      this._scheduleReconnect();
    }
  }

  _attachEvents() {
    const bot = this.bot;

    bot.once('login', () => {
      this.isConnecting = false;
      this.status = 'connected';
      this.reconnectAttempts = 0;
      this.startTime = Date.now();
      this.stats.connectedAt = new Date().toISOString();
      this.stats.disconnectedAt = null;
      this.log('info', `✅ Connected successfully! Entity ID: ${bot.entity?.id}`);
      this.emit('statusChange', { status: 'connected', botId: this.id });
      this._startAfkMovement();
      this._handleAutoCommands();
    });

    bot.on('spawn', () => {
      this.log('info', `Bot spawned at ${JSON.stringify(bot.entity?.position)}`);
      this._updatePlayerList();
    });

    bot.on('chat', (username, message) => {
      const filtered = this.settings.chatFilterEnabled &&
        this.settings.chatFilterWords?.some(w => message.toLowerCase().includes(w.toLowerCase()));
      if (!filtered) {
        const entry = {
          time: new Date().toISOString(),
          username,
          message,
          type: 'chat'
        };
        this.chatHistory.push(entry);
        if (this.chatHistory.length > 200) this.chatHistory.shift();
        this.emit('chat', { ...entry, botId: this.id });
        this.log('info', `<${username}> ${message}`);
      }
    });

    bot.on('message', (jsonMsg) => {
      try {
        const text = jsonMsg.toString();
        if (text && text.trim()) {
          const entry = {
            time: new Date().toISOString(),
            username: 'SYSTEM',
            message: text,
            type: 'system'
          };
          this.chatHistory.push(entry);
          if (this.chatHistory.length > 200) this.chatHistory.shift();
          this.emit('chat', { ...entry, botId: this.id });
        }
      } catch (e) {}
    });

    bot.on('playerJoined', (player) => {
      this._updatePlayerList();
      this.log('info', `➕ ${player.username} joined`);
    });

    bot.on('playerLeft', (player) => {
      this._updatePlayerList();
      this.log('info', `➖ ${player.username} left`);
    });

    bot.on('health', () => {
      this.emit('statsUpdate', {
        botId: this.id,
        health: bot.health,
        food: bot.food,
        ping: bot.player?.ping || 0
      });
    });

    bot.on('time', () => {
      this.ping = bot.player?.ping || 0;
    });

    bot._client?.on('ping', (latency) => {
      this.ping = latency;
    });

    bot.on('kicked', (reason) => {
      const reasonStr = typeof reason === 'string' ? reason : JSON.stringify(reason);
      this.status = 'disconnected';
      this.lastError = `Kicked: ${reasonStr}`;
      this.log('warn', `⚠️ Kicked: ${reasonStr}`);
      this.emit('statusChange', { status: 'kicked', reason: reasonStr, botId: this.id });
      this._cleanup();
      this._scheduleReconnect();
    });

    bot.on('error', (err) => {
      this.lastError = err.message;
      this.log('error', `❌ Error: ${err.message}`);
      this.emit('statusChange', { status: 'error', error: err.message, botId: this.id });
    });

    bot.on('end', (reason) => {
      this.isConnecting = false;
      this.status = 'disconnected';
      this.stats.disconnectedAt = new Date().toISOString();
      if (this.startTime) {
        this.stats.totalUptime += Date.now() - this.startTime;
        this.startTime = null;
      }
      this.log('warn', `🔌 Disconnected: ${reason || 'unknown'}`);
      this.emit('statusChange', { status: 'disconnected', reason, botId: this.id });
      this._cleanup();
      if (this.shouldReconnect) this._scheduleReconnect();
    });
  }

  _updatePlayerList() {
    if (!this.bot) return;
    this.players = Object.values(this.bot.players || {}).map(p => ({
      username: p.username,
      ping: p.ping,
      uuid: p.uuid
    }));
    this.playerCount = this.players.length;
    this.emit('playersUpdate', { botId: this.id, players: this.players, count: this.playerCount });
  }

  _handleAutoCommands() {
    if (!this.bot) return;
    const delay = (ms) => new Promise(r => setTimeout(r, ms));
    (async () => {
      await delay(2000);
      if (this.settings.autoRegister && this.settings.registerPassword) {
        this.sendChat(`/register ${this.settings.registerPassword} ${this.settings.registerPassword}`);
        this.log('info', 'Auto-register command sent');
        await delay(1500);
      }
      if (this.settings.autoLogin && this.settings.loginPassword) {
        this.sendChat(`/login ${this.settings.loginPassword}`);
        this.log('info', 'Auto-login command sent');
      }
    })();
  }

  _startAfkMovement() {
    this._stopAfkMovement();
    const interval = this.settings.afkMovementInterval || 30000;
    this.afkTimer = setInterval(() => {
      if (this.bot && this.status === 'connected') {
        this._performAfkMove();
      }
    }, interval);
  }

  _performAfkMove() {
    if (!this.bot?.entity) return;
    try {
      const moves = [
        () => { this.bot.setControlState('forward', true); setTimeout(() => this.bot.setControlState('forward', false), 200); },
        () => { this.bot.setControlState('back', true); setTimeout(() => this.bot.setControlState('back', false), 200); },
        () => { this.bot.setControlState('left', true); setTimeout(() => this.bot.setControlState('left', false), 200); },
        () => { this.bot.setControlState('right', true); setTimeout(() => this.bot.setControlState('right', false), 200); },
        () => { this.bot.setControlState('jump', true); setTimeout(() => this.bot.setControlState('jump', false), 100); },
        () => { this.bot.look(Math.random() * Math.PI * 2, (Math.random() - 0.5) * 0.5, true); }
      ];
      moves[Math.floor(Math.random() * moves.length)]();
      this.log('info', '🎮 AFK movement performed');
    } catch (e) {}
  }

  _stopAfkMovement() {
    if (this.afkTimer) {
      clearInterval(this.afkTimer);
      this.afkTimer = null;
    }
  }

  _scheduleReconnect() {
    if (!this.shouldReconnect) return;
    const maxAttempts = this.settings.maxReconnectAttempts;
    if (maxAttempts > 0 && this.reconnectAttempts >= maxAttempts) {
      this.log('error', `Max reconnect attempts (${maxAttempts}) reached`);
      return;
    }

    this.reconnectAttempts++;
    this.stats.reconnects++;
    const delay = Math.min(this.settings.reconnectDelay * Math.pow(1.5, Math.min(this.reconnectAttempts - 1, 5)), 60000);
    this.log('info', `🔄 Reconnecting in ${Math.round(delay / 1000)}s (attempt ${this.reconnectAttempts})`);
    this.emit('statusChange', { status: 'reconnecting', attempt: this.reconnectAttempts, delay, botId: this.id });

    this.reconnectTimer = setTimeout(() => {
      if (this.shouldReconnect) this.connect();
    }, delay);
  }

  _cleanup() {
    this._stopAfkMovement();
    if (this.bot) {
      try { this.bot.removeAllListeners(); } catch (e) {}
      this.bot = null;
    }
  }

  disconnect() {
    this.shouldReconnect = false;
    if (this.reconnectTimer) { clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
    this._cleanup();
    if (this.status !== 'disconnected') {
      this.status = 'disconnected';
      this.emit('statusChange', { status: 'disconnected', botId: this.id });
    }
    this.log('info', 'Bot manually disconnected');
  }

  sendChat(message) {
    if (!this.bot || this.status !== 'connected') {
      this.log('warn', 'Cannot send message: bot not connected');
      return false;
    }
    try {
      this.bot.chat(message);
      this.stats.messagesSent++;
      this.log('info', `📤 Sent: ${message}`);
      return true;
    } catch (err) {
      this.log('error', `Failed to send message: ${err.message}`);
      return false;
    }
  }

  getStatus() {
    return {
      id: this.id,
      name: this.config.name,
      username: this.config.username,
      host: this.config.host,
      port: this.config.port,
      version: this.config.version,
      auth: this.config.auth,
      status: this.status,
      ping: this.ping,
      playerCount: this.playerCount,
      players: this.players,
      uptime: this.startTime ? Date.now() - this.startTime : 0,
      reconnectAttempts: this.reconnectAttempts,
      lastError: this.lastError,
      stats: this.stats,
      health: this.bot?.health,
      food: this.bot?.food,
      position: this.bot?.entity?.position
    };
  }

  getHistory() {
    return { chat: this.chatHistory, console: this.consoleHistory };
  }
}

module.exports = { BotInstance, SUPPORTED_VERSIONS };
