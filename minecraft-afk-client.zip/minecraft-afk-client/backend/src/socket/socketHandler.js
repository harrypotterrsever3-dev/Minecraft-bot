const { socketAuth } = require('../middleware/auth');
const logger = require('../utils/logger');
const os = require('os');

module.exports = (io, botManager) => {
  // Optional socket auth (enable in production)
  // io.use(socketAuth);

  io.on('connection', (socket) => {
    logger.info(`WebSocket connected: ${socket.id}`);

    // Send initial data
    socket.emit('init', {
      bots: botManager.getAllBots(),
      settings: botManager.getSettings(),
      versions: botManager.getSupportedVersions()
    });

    // System stats interval
    const statsInterval = setInterval(() => {
      const memUsage = process.memoryUsage();
      socket.emit('systemStats', {
        cpu: os.loadavg()[0].toFixed(2),
        memory: {
          used: Math.round(memUsage.rss / 1024 / 1024),
          heap: Math.round(memUsage.heapUsed / 1024 / 1024)
        },
        uptime: Math.round(process.uptime())
      });
    }, 5000);

    // Bot history on request
    socket.on('getBotHistory', ({ botId }) => {
      try {
        const history = botManager.getBotHistory(botId);
        socket.emit('botHistory', { botId, ...history });
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Start bot
    socket.on('startBot', ({ botId }) => {
      try {
        botManager.startBot(botId);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Stop bot
    socket.on('stopBot', ({ botId }) => {
      try {
        botManager.stopBot(botId);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Send chat
    socket.on('sendChat', ({ botId, message }) => {
      try {
        botManager.sendMessage(botId, message);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Add bot
    socket.on('addBot', (config) => {
      try {
        const bot = botManager.addBot(config);
        if (config.autoStart) botManager.startBot(bot.id || config.id);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Remove bot
    socket.on('removeBot', ({ botId }) => {
      try {
        botManager.removeBot(botId);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // Update settings
    socket.on('updateSettings', (settings) => {
      try {
        const updated = botManager.updateSettings(settings);
        io.emit('settingsUpdated', updated);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    socket.on('disconnect', () => {
      clearInterval(statsInterval);
      logger.info(`WebSocket disconnected: ${socket.id}`);
    });
  });
};
