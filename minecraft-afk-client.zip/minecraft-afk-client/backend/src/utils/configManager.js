const fs = require('fs');
const path = require('path');
const logger = require('./logger');

const CONFIG_PATH = process.env.CONFIG_PATH || path.join(__dirname, '../../../configs/config.json');

const defaultConfig = {
  bots: [],
  settings: {
    reconnectDelay: 5000,
    maxReconnectAttempts: -1,
    afkMovementInterval: 30000,
    chatFilterEnabled: false,
    chatFilterWords: [],
    soundNotifications: true,
    autoRegister: false,
    registerPassword: '',
    autoLogin: false,
    loginPassword: ''
  }
};

function readConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) {
      writeConfig(defaultConfig);
      return defaultConfig;
    }
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    return { ...defaultConfig, ...JSON.parse(raw) };
  } catch (err) {
    logger.error(`Failed to read config: ${err.message}`);
    return defaultConfig;
  }
}

function writeConfig(config) {
  try {
    const dir = path.dirname(CONFIG_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (err) {
    logger.error(`Failed to write config: ${err.message}`);
    return false;
  }
}

function updateSettings(newSettings) {
  const config = readConfig();
  config.settings = { ...config.settings, ...newSettings };
  return writeConfig(config);
}

function saveBotConfig(botId, botConfig) {
  const config = readConfig();
  const idx = config.bots.findIndex(b => b.id === botId);
  if (idx >= 0) {
    config.bots[idx] = { ...config.bots[idx], ...botConfig };
  } else {
    config.bots.push(botConfig);
  }
  return writeConfig(config);
}

function removeBotConfig(botId) {
  const config = readConfig();
  config.bots = config.bots.filter(b => b.id !== botId);
  return writeConfig(config);
}

module.exports = { readConfig, writeConfig, updateSettings, saveBotConfig, removeBotConfig };
