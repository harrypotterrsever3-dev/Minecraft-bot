require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const path = require('path');

const logger = require('./utils/logger');
const { createAuthMiddleware } = require('./middleware/auth');
const { apiLimiter } = require('./middleware/rateLimit');
const createApiRoutes = require('./routes/api');
const setupSocketHandler = require('./socket/socketHandler');
const BotManager = require('./bot/BotManager');

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
    credentials: true
  },
  pingTimeout: 60000,
  pingInterval: 25000
});

// Middleware
app.use(compression());
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || '*', credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
app.use('/api', apiLimiter);

// Basic auth for API (optional, enable in production)
if (process.env.NODE_ENV === 'production') {
  app.use('/api', createAuthMiddleware());
}

// Serve built frontend
const frontendBuild = path.join(__dirname, '../../frontend/build');
app.use(express.static(frontendBuild));

// Initialize BotManager
const botManager = new BotManager(io);

// API Routes
app.use('/api', createApiRoutes(botManager));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), bots: botManager.getAllBots().length });
});

// Catch-all for SPA
app.get('*', (req, res) => {
  const indexPath = path.join(frontendBuild, 'index.html');
  if (require('fs').existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.json({ message: 'Minecraft AFK Client API', version: '1.0.0', docs: '/api/bots' });
  }
});

// Socket.IO
setupSocketHandler(io, botManager);

// Error handling
app.use((err, req, res, next) => {
  logger.error(`Unhandled error: ${err.message}`);
  res.status(500).json({ error: 'Internal server error' });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully...');
  botManager.stopAll();
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught exception: ${err.message}`);
});

process.on('unhandledRejection', (reason) => {
  logger.error(`Unhandled rejection: ${reason}`);
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  logger.info(`🚀 Minecraft AFK Client server running on port ${PORT}`);
  logger.info(`📊 Web Panel: http://localhost:${PORT}`);
  logger.info(`🔌 API: http://localhost:${PORT}/api`);
  logger.info(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = { app, server, io };
