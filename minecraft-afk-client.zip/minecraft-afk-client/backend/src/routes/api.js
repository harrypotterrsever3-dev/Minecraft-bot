const express = require('express');
const router = express.Router();
const { chatLimiter } = require('../middleware/rateLimit');
const os = require('os');

module.exports = (botManager) => {
  // System info
  router.get('/system', (req, res) => {
    const memUsage = process.memoryUsage();
    res.json({
      cpu: os.loadavg()[0],
      memory: {
        used: Math.round(memUsage.rss / 1024 / 1024),
        heap: Math.round(memUsage.heapUsed / 1024 / 1024),
        total: Math.round(os.totalmem() / 1024 / 1024),
        free: Math.round(os.freemem() / 1024 / 1024)
      },
      uptime: process.uptime(),
      platform: os.platform(),
      nodeVersion: process.version
    });
  });

  // Get all bots
  router.get('/bots', (req, res) => {
    try {
      res.json(botManager.getAllBots());
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Add bot
  router.post('/bots', (req, res) => {
    try {
      const { username, host, port, version, auth, name, autoStart } = req.body;
      if (!username || !host) return res.status(400).json({ error: 'username and host required' });
      const bot = botManager.addBot({ username, host, port: port || 25565, version, auth: auth || 'offline', name: name || username, autoStart: autoStart || false });
      if (autoStart) botManager.startBot(bot.id);
      res.status(201).json(bot.getStatus ? bot.getStatus() : bot);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Get bot
  router.get('/bots/:id', (req, res) => {
    try {
      const bot = botManager.getBot(req.params.id);
      res.json(bot.getStatus());
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  // Update bot config
  router.put('/bots/:id', (req, res) => {
    try {
      const result = botManager.updateBotConfig(req.params.id, req.body);
      res.json(result);
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  // Delete bot
  router.delete('/bots/:id', (req, res) => {
    try {
      botManager.removeBot(req.params.id);
      res.json({ success: true });
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  // Start bot
  router.post('/bots/:id/start', (req, res) => {
    try {
      const result = botManager.startBot(req.params.id);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Stop bot
  router.post('/bots/:id/stop', (req, res) => {
    try {
      const result = botManager.stopBot(req.params.id);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Send chat
  router.post('/bots/:id/chat', chatLimiter, (req, res) => {
    try {
      const { message } = req.body;
      if (!message) return res.status(400).json({ error: 'message required' });
      const success = botManager.sendMessage(req.params.id, message);
      res.json({ success });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Get bot history
  router.get('/bots/:id/history', (req, res) => {
    try {
      const history = botManager.getBotHistory(req.params.id);
      res.json(history);
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  // Start all bots
  router.post('/bots/all/start', (req, res) => {
    botManager.startAll();
    res.json({ success: true });
  });

  // Stop all bots
  router.post('/bots/all/stop', (req, res) => {
    botManager.stopAll();
    res.json({ success: true });
  });

  // Supported versions
  router.get('/versions', (req, res) => {
    res.json(botManager.getSupportedVersions());
  });

  // Get global settings
  router.get('/settings', (req, res) => {
    res.json(botManager.getSettings());
  });

  // Update global settings
  router.put('/settings', (req, res) => {
    try {
      const settings = botManager.updateSettings(req.body);
      res.json(settings);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  return router;
};
