const basicAuth = require('express-basic-auth');

function createAuthMiddleware() {
  const username = process.env.PANEL_USERNAME || 'admin';
  const password = process.env.PANEL_PASSWORD || 'changeme123';

  return basicAuth({
    users: { [username]: password },
    challenge: true,
    realm: 'Minecraft AFK Panel'
  });
}

function socketAuth(socket, next) {
  const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization;
  const username = process.env.PANEL_USERNAME || 'admin';
  const password = process.env.PANEL_PASSWORD || 'changeme123';
  const expected = Buffer.from(`${username}:${password}`).toString('base64');

  if (token === expected || process.env.NODE_ENV === 'development') {
    next();
  } else {
    next(new Error('Authentication error'));
  }
}

module.exports = { createAuthMiddleware, socketAuth };
