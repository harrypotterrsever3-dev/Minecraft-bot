# ⛏ Minecraft AFK Console Client

> 7/24 çalışan, web panelden kontrol edilebilen profesyonel Minecraft AFK bot sistemi.

![Node.js](https://img.shields.io/badge/Node.js-20+-green?logo=node.js)
![React](https://img.shields.io/badge/React-18-blue?logo=react)
![Socket.IO](https://img.shields.io/badge/Socket.IO-4-black?logo=socket.io)
![License](https://img.shields.io/badge/License-MIT-yellow)

## ✨ Özellikler

- 🤖 **Çoklu Bot** — Aynı anda birden fazla botu farklı sunucularda çalıştır
- 🔄 **Auto Reconnect** — Kick, sunucu restart, internet kesintisinde otomatik yeniden bağlan
- 🎮 **AFK Sistemi** — Rastgele hareket ile AFK kick engeli
- 💬 **Canlı Chat** — Web panelden mesaj gönder / al (Socket.IO)
- 🖥 **Terminal Konsol** — Gerçek zamanlı bot logları
- 📊 **İstatistikler** — Ping, health, food, oyuncu listesi
- 🔐 **Auth Desteği** — Premium (Microsoft) ve Offline/Cracked
- 🔑 **Auto Login/Register** — Otomatik `/register` ve `/login` komutu
- 🌓 **Karanlık Tema** — Modern GitHub-tarzı arayüz
- 📱 **Mobil Uyumlu** — Responsive tasarım
- 🔒 **Güvenlik** — Rate limiting, Basic Auth
- 🐳 **Docker** — Tek komutla deploy
- ⚡ **PM2** — Üretim ortamı process yönetimi

---

## 🚀 Hızlı Başlangıç

### Gereksinimler
- Node.js 18+
- npm 9+
- Git

### 1. Repoyu Klonla
```bash
git clone https://github.com/KULLANICIADI/minecraft-afk-client.git
cd minecraft-afk-client
```

### 2. Bağımlılıkları Kur
```bash
npm run install:all
# veya ayrı ayrı:
cd backend && npm install
cd ../frontend && npm install
```

### 3. Ortam Değişkenlerini Ayarla
```bash
cp backend/.env.example backend/.env
# backend/.env dosyasını düzenle:
nano backend/.env
```

**Kritik değişkenler:**
```env
PANEL_USERNAME=admin
PANEL_PASSWORD=guclu-bir-sifre
PORT=3001
```

### 4. Frontend'i Derle
```bash
npm run build
```

### 5. Başlat
```bash
# Development
npm run dev:backend   # Backend: port 3001
npm run dev:frontend  # Frontend: port 3000

# Production
npm start
```

Web paneli aç: **http://localhost:3001**

---

## 🐳 Docker ile Çalıştır

```bash
# .env dosyasını oluştur
cp backend/.env.example .env

# Derle ve başlat
docker compose up -d

# Logları izle
docker compose logs -f

# Durdur
docker compose down
```

---

## ⚡ PM2 ile 7/24 Çalıştır

```bash
# Önce frontend'i derle
npm run build

# PM2 ile başlat
npm run pm2:start

# Sistem başlangıcında otomatik çalıştır
pm2 startup
pm2 save

# Loglar
npm run pm2:logs

# Yeniden başlat
npm run pm2:restart
```

---

## 🗂 Proje Yapısı

```
minecraft-afk-client/
├── backend/
│   ├── src/
│   │   ├── bot/
│   │   │   ├── BotInstance.js     # Tek bot mantığı (mineflayer)
│   │   │   └── BotManager.js      # Çoklu bot yönetimi
│   │   ├── routes/
│   │   │   └── api.js             # REST API endpoints
│   │   ├── socket/
│   │   │   └── socketHandler.js   # Socket.IO olayları
│   │   ├── middleware/
│   │   │   ├── auth.js            # Basic Auth
│   │   │   └── rateLimit.js       # Rate limiting
│   │   ├── utils/
│   │   │   ├── logger.js          # Winston logger
│   │   │   └── configManager.js   # JSON config yönetimi
│   │   └── server.js              # Express + Socket.IO sunucu
│   ├── .env.example
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── BotCard/           # Bot kartı + Modal
│   │   │   ├── Chat/              # Canlı chat paneli
│   │   │   ├── Console/           # Terminal konsol
│   │   │   └── Stats/             # İstatistik + Ayarlar
│   │   ├── hooks/
│   │   │   └── useSocket.jsx      # Socket.IO context/hook
│   │   ├── App.jsx                # Ana dashboard
│   │   └── index.js
│   └── package.json
├── configs/
│   └── config.json                # Bot ve ayar verisi
├── .github/
│   └── workflows/
│       └── ci.yml                 # GitHub Actions CI/CD
├── ecosystem.config.js            # PM2 konfigürasyonu
├── Dockerfile
├── docker-compose.yml
└── package.json
```

---

## 🔌 API Endpoints

| Method | Endpoint | Açıklama |
|--------|----------|----------|
| GET | `/api/bots` | Tüm botları listele |
| POST | `/api/bots` | Yeni bot ekle |
| GET | `/api/bots/:id` | Bot detayı |
| PUT | `/api/bots/:id` | Bot güncelle |
| DELETE | `/api/bots/:id` | Bot sil |
| POST | `/api/bots/:id/start` | Botu başlat |
| POST | `/api/bots/:id/stop` | Botu durdur |
| POST | `/api/bots/:id/chat` | Chat gönder |
| GET | `/api/bots/:id/history` | Chat/console geçmişi |
| GET | `/api/versions` | Desteklenen MC versiyonları |
| GET | `/api/settings` | Global ayarlar |
| PUT | `/api/settings` | Ayarları güncelle |
| GET | `/api/system` | CPU/RAM bilgisi |
| GET | `/health` | Health check |

---

## 🔌 Socket.IO Olayları

### Server → Client
| Olay | Açıklama |
|------|----------|
| `init` | İlk bağlantıda tüm veriler |
| `botAdded` | Yeni bot eklendi |
| `botRemoved` | Bot silindi |
| `botStatusChange` | Bağlantı durumu değişti |
| `botChat` | Chat mesajı geldi |
| `botLog` | Konsol log |
| `botPlayersUpdate` | Oyuncu listesi güncellendi |
| `systemStats` | CPU/RAM istatistikleri |

### Client → Server
| Olay | Açıklama |
|------|----------|
| `startBot` | Botu başlat |
| `stopBot` | Botu durdur |
| `sendChat` | Mesaj/komut gönder |
| `addBot` | Yeni bot ekle |
| `removeBot` | Bot sil |
| `updateSettings` | Ayarları güncelle |

---

## 🚀 GitHub Actions ile Otomatik Deploy

`.github/workflows/ci.yml` dosyası:
- Her `push`/`PR` → Frontend build + lint
- `main` branch → Docker image build
- SSH deploy (opsiyonel)

**GitHub Secrets ayarları** (opsiyonel SSH deploy için):
```
SSH_HOST        = sunucu IP
SSH_USER        = kullanıcı adı
SSH_PRIVATE_KEY = özel SSH anahtarı
SSH_PORT        = 22
DEPLOY_PATH     = ~/minecraft-afk-client
```

`Settings > Variables > DEPLOY_ENABLED = true` ile deploy aktif olur.

---

## ⚙️ Desteklenen Minecraft Versiyonları

1.8.9, 1.9.4, 1.10.2, 1.11.2, 1.12.2, 1.13.2, 1.14.4, 1.15.2, 1.16.5, 1.17.1, 1.18.2, 1.19.4, 1.20.1, 1.20.4, 1.20.6, 1.21.1, 1.21.4

---

## 🔒 Güvenlik

- Basic Auth ile panel koruması (üretimde aktif)
- API rate limiting (15dk/100 istek)
- Chat rate limiting (10sn/10 mesaj)
- Helmet.js ile HTTP güvenlik başlıkları
- `.env` ile hassas bilgi yönetimi

---

## 📝 Lisans

MIT © 2024
